package com.b0roka.SRTLN_sk8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrtlnSk8Application {

	public static void main(String[] args) {
		SpringApplication.run(SrtlnSk8Application.class, args);
	}

}
