package com.b0roka.SRTLN_sk8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrtlnSk8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
